import fs from 'node:fs';
import path from 'node:path';
import {validateLibrary} from './lib/contract.mjs';
import {Store,Runner,exportRun} from './lib/runner.mjs';
import {ROOT} from './server.mjs';
async function main(){const [command,file,...args]=process.argv.slice(2);if(!['validate','run'].includes(command)||!file){console.log('node cli.mjs validate <library.json>\nnode cli.mjs run <library.json> [--suite ID | --tests ID,ID] [--output ORDNER] [--allow-commands]');return 2}const library=validateLibrary(JSON.parse(fs.readFileSync(path.resolve(file),'utf8')));if(command==='validate'){console.log(`Gültig: ${library.tests.length} Tests, ${library.suites.length} Testpläne`);return 0}
 const val=key=>{const i=args.indexOf(key);return i<0?undefined:args[i+1]};library.settings={allowCommands:args.includes('--allow-commands')};
 const dir=path.resolve(val('--output')??path.join(ROOT,'evidence','cli-'+Date.now()));if(fs.existsSync(path.join(dir,'library.json')))throw Error('Ausgabeordner enthält bereits eine Bibliothek; neuen Laufordner wählen');const store=new Store(dir,library),runner=new Runner(store);const options=val('--suite')?{suiteId:val('--suite')}:{testIds:val('--tests')?.split(',')??library.tests.filter(t=>t.enabled!==false).map(t=>t.id)};const run=runner.start(options);process.once('SIGINT',()=>runner.cancel(run.id));await runner.completion;fs.writeFileSync(path.join(dir,'results.xml'),exportRun(run,'junit'));fs.writeFileSync(path.join(dir,'results.csv'),exportRun(run,'csv'));console.log(JSON.stringify({id:run.id,status:run.status,summary:store.listRuns()[0].summary,output:dir},null,2));return run.status==='passed'?0:run.status==='error'?2:1}
main().then(code=>process.exitCode=code).catch(e=>{console.error(e.message);process.exitCode=2});
